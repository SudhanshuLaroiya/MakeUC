msg = "Hello World"
print(msg)
print("HOE")
print("chocolate")
print("chocolate")
print("its annoying")
print("cocoa")
print("what is the pull??")
package atrijoke;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;

public class budgetbuddy {

	private JFrame frame;
	private static JTextField textField;
	private JLabel lblNewLabel_1;
	private JLabel label34;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					budgetbuddy window = new budgetbuddy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public budgetbuddy() throws IOException {
		initialize();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	private void initialize() throws IOException {
		frame = new JFrame();
		BufferedImage image = ImageIO.read(new File("C:/Users/User/eclipse-workspace/atrijoke/src/atrijoke/food.png"));
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.WHITE);
		frame.setBounds(20, 30, 583, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel(String.format("<html><body style=\" text-align: justify; text-justify: inter-word;\"> %s </body></html>","Struggling to find a place to eat within your budget? Don't worry, Budgeat is here to help! Tell us your budget and the amount of meals you'd like to have. Budgeat will have the plan ready in less than a minute."));
		lblNewLabel.setFont(new Font("Segoe UI Semibold", Font.ITALIC, 25));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setToolTipText("wrap");
		lblNewLabel.setBounds(81, 292, 408, 265);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setBounds(206, 642, 161, 31);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Please enter your budget over here");
		lblNewLabel_1.setFont(new Font("Sitka Small", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(111, 593, 367, 39);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton letsgobutton = new JButton("Lets Go!");
		letsgobutton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		letsgobutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				page2.main(null);
			}
		});
		letsgobutton.setBounds(234, 683, 99, 21);
		frame.getContentPane().add(letsgobutton);
		
		
		
		label34 = new JLabel(new ImageIcon(image));
		label34.setText("");
		label34.setBounds(-10
				, 0, 583, 870);
		frame.getContentPane().add(label34);
		lblNewLabel_2 = new JLabel("Budg-eat");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_2.setFont(new Font("Bauhaus 93", Font.ITALIC, 49));
		lblNewLabel_2.setBounds(175, 124, 208, 78);
		frame.getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Welcome to Budg-eat!");
		lblNewLabel_3.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_3.setBounds(140, 251, 293, 31);
		frame.getContentPane().add(lblNewLabel_3);
		
		//private BufferedImage image;
		
		//image = ImageIO.read(getClass.getResource(?));
		
	}

	public static JTextField gettextField() {
		// TODO Auto-generated method stub
		return textField;
	}
}

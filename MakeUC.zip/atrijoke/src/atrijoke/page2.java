package atrijoke;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JSlider;
import java.awt.Font;

public class page2 {

	private JFrame frame;
	private JLabel lblNewLabel_2;
	private JTextField textField_2;
	private JLabel PIC_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					page2 window = new page2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public page2() throws IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	private void initialize() throws IOException {
		frame = new JFrame();
		frame.setBounds(20, 30, 583, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("How many meals would you like?");
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 20));
		lblNewLabel.setBounds(96, 295, 387, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("How Healthy do you want your meal?");
		lblNewLabel_1.setFont(new Font("Sitka Small", Font.BOLD, 20));
		lblNewLabel_1.setBounds(96, 381, 447, 51);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton bonappetite = new JButton("Bon Appetite");
		bonappetite.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 16));
		bonappetite.setBounds(209, 609, 146, 37);
		frame.getContentPane().add(bonappetite);
		
//JButtonm bonappetite = new JButton("Bon Appetite");
		bonappetite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				page3.main(null);
				
			}
		});
		
	
		
		lblNewLabel_2 = new JLabel("Any Allergy?(leave Blank if none)");
		lblNewLabel_2.setFont(new Font("Sitka Small", Font.BOLD, 20));
		lblNewLabel_2.setBounds(96, 505, 362, 31);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(199, 560, 167, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JSlider slider = new JSlider();
		slider.setMaximum(10);
		slider.setBounds(180, 437, 200, 22);
		frame.getContentPane().add(slider);
		
		JLabel lblNewLabel_3 = new JLabel("0 ");
		lblNewLabel_3.setBounds(200, 170, 45, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("0");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel_4.setBounds(157, 452, 39, 38);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("healthiest");
		lblNewLabel_5.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_5.setBounds(361, 458, 182, 37);
		frame.getContentPane().add(lblNewLabel_5);
		
		JSlider slider_1 = new JSlider();
		slider_1.setMaximum(20);
		slider_1.setBounds(180, 337, 200, 22);
		frame.getContentPane().add(slider_1);
		
		JLabel lblNewLabel_6 = new JLabel("0");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel_6.setBounds(157, 353, 39, 31);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("20");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_7.setBounds(383, 359, 45, 21);
		frame.getContentPane().add(lblNewLabel_7);
		
		BufferedImage image = ImageIO.read(new File("C:/Users/User/eclipse-workspace/atrijoke/src/atrijoke/food.png"));

		JLabel PIC = new JLabel("");
				frame.getContentPane().add(PIC);
		PIC_1 = new JLabel(new ImageIcon(image));
		PIC_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		PIC_1.setText("");
		PIC_1.setBounds(-10
				, 0, 583, 870);
		frame.getContentPane().add(PIC_1);
		
	}
}

package atrijoke;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JSpinner;
import javax.swing.JRadioButton;

public class page3 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					page3 window = new page3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public page3() throws IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	private void initialize() throws IOException {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		BufferedImage image = ImageIO.read(new File("C:/Users/User/eclipse-workspace/atrijoke/src/atrijoke/food.png"));
		frame.setBounds(20, 30, 583, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel((String) null);
		lblNewLabel.setBounds(10, 110, 71, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(161, 30, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Refresh");
		btnNewButton.setBounds(104, 56, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("More info");
		btnNewButton_1.setBounds(189, 56, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
		lblNewLabel.setBounds(10, 30, 50, 43);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(125, 87, 135, 81);
		frame.getContentPane().add(scrollPane);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(284, 53, 135, 129);
		frame.getContentPane().add(panel_1);
		
		JLabel pic = new JLabel("");
	//	frame.getContentPane().add(PIC);
			pic = new JLabel(new ImageIcon(image));
			pic.setFont(new Font("Tahoma", Font.PLAIN, 22));
			pic.setText("");
			pic.setBounds(-10, 0, 583, 870);
			frame.getContentPane().add(pic);

	
	
		
	}
}
